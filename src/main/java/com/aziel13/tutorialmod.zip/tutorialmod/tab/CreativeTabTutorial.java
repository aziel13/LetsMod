package com.aziel13.tutorialmod.tab;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Items;
import net.minecraft.item.Item;

/**
 * Created by Will on 1/14/2017.
 */
public class CreativeTabTutorial extends CreativeTabs {


    public CreativeTabTutorial(String label) {
        super(label);
    }

    public CreativeTabTutorial(int index, String label) {
        super(index, label);
    }

    @Override
    public Item getTabIconItem() {

        return Items.EMERALD;
    }
}
