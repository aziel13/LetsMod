package com.aziel13.tutorialmod;

import com.aziel13.tutorialmod.item.ModItems;
import com.aziel13.tutorialmod.proxy.CommonProxy;
import com.aziel13.tutorialmod.tab.CreativeTabTutorial;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = TutorialMod.MODID, version = TutorialMod.VERSION, name = TutorialMod.NAME)
public class TutorialMod
{
    public static final String MODID = "tutorialmod";
    public static final String VERSION = "1.0";
    public static final String NAME = "tutorial mod";
    public static final String CLIENT_PROXY_CLASS = "com.aziel13.tutorialmod.proxy.ClientProxy";

    @Mod.Instance(TutorialMod.MODID)
    public static TutorialMod instance;

    @SidedProxy(clientSide = CLIENT_PROXY_CLASS, serverSide = "com.aziel13.tutorialmod.proxy.CommonProxy")
    public static CommonProxy proxy;

    public static CreativeTabTutorial tabTutorial;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event){
        tabTutorial = new CreativeTabTutorial(CreativeTabs.getNextID(), "tutorial_tab");
        ModItems.preInit();
        proxy.preInit(event);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {

        //  ModItems.registerRender();
        proxy.init(event);

    }

    @Mod.EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        proxy.postInit(event);

    }

}
